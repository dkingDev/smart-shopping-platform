# Heroku Deployment Instructions

## Prerequisites
1. Create a Heroku account
2. Install Heroku CLI
3. Have your AWS PostgreSQL credentials ready

## Deployment Steps

1. **Create Heroku App**
   ```bash
   heroku create your-app-name
   ```

2. **Set Environment Variables**
   ```bash
   heroku config:set DATABASE_URL="postgresql://username:password@hostname:port/database"
   heroku config:set JWT_SECRET_KEY="your-super-secure-jwt-secret-key"
   heroku config:set AWS_ACCESS_KEY_ID="your-aws-access-key"
   heroku config:set AWS_SECRET_ACCESS_KEY="your-aws-secret-key"
   heroku config:set AWS_REGION="your-aws-region"
   ```

3. **Deploy**
   ```bash
   git init
   git add .
   git commit -m "Initial deployment"
   git remote add heroku https://git.heroku.com/your-app-name.git
   git push heroku main
   ```

4. **Verify**
   ```bash
   heroku logs --tail
   heroku open
   ```

## API Endpoints
- POST /register - User registration
- POST /login - User login
- GET /shopping-lists - Get user's shopping lists
- POST /shopping-lists - Create new shopping list

## Security Notes
- All endpoints require JWT authentication (except register/login)
- User data is stored in AWS PostgreSQL
- No sensitive data is logged or cached
