# Smart Shopping Platform

**Live Demo:** https://YOURUSERNAME.github.io/smart-shopping-platform

## Features
- User Registration & Login
- Shopping List Management  
- Price Comparison
- Store Analysis
- Secure Authentication

## Setup
This is a frontend-only repository. The backend API is hosted separately.

## Usage
1. Open the live demo link above
2. Register a new account or login
3. Start creating shopping lists and comparing prices

---
*Powered by Smart Shopping Platform*
